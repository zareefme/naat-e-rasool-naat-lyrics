Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_naat-e-rasool-naat-lyrics-de_DE.po
* app_naat-e-rasool-naat-lyrics-id_ID.po
* app_naat-e-rasool-naat-lyrics_ES.po
* app_naat-e-rasool-naat-lyrics-en_US.po
* app_naat-e-rasool-naat-lyrics-de_DE.mo
* app_naat-e-rasool-naat-lyrics-id_ID.mo
* app_naat-e-rasool-naat-lyrics-es_ES.mo
* app_naat-e-rasool-naat-lyrics-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
